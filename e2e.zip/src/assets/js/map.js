
var geojsondata = [];
var mymap;
var render_polygon_ids = [];

function test1(){
   var ajax_count = 0;
   var lati;
   var longi;
   var getParams = function (url) {
     var params = {};
     var parser = document.createElement('a');
     parser.href = url;
     var query = parser.search.substring(1);
     var vars = query.split('&');
     for (var i = 0; i < vars.length; i++) {
       var pair = vars[i].split('=');
       params[pair[0]] = decodeURIComponent(pair[1]);
     }
     var vars = url.split('=');
     return params;
   };
 
  var loc =getParams(window.location.href).location;
    var ata = loc.split(',');
    lati = ata[0];
    longi = ata[1];
 
mymap = L.map('mapid').setView([lati, longi], 19);
 //console.log(mymap);
 L.tileLayer = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
     maxZoom: 24,
     subdomains:['mt0','mt1','mt2','mt3']
 }).addTo(mymap);
 
 var mappage = getParams(window.location.href);
 
 
//  function showinfowindow(layer){
//       if(layer.feature.properties.plotid) {
//         var html="<table style='border:1px solid'>"+
//         "<tr><td>Grave Code:"+layer.feature.properties.plotid+"</td></tr><tr></tr>";
//         $.post("https://api-dot-ezy-geospatial.appspot.com/user/AllgetPersonData", {
//         plot_id:layer.feature.properties.plotid
//               }, function (plotData) {
//        var obj = JSON.parse(plotData);
       
//         for(var j=0; j<obj.length; j++){
//           html += "<tr><td>Burial Date:"+obj[j].dod+"</td></tr>"+
//         "<tr><td>Name:"+obj[j].first_name+"</td></tr>";
//         }
      
//         if(obj.length !== 0 && sessionStorage['cemetery_id'] !== undefined && obj[0] !== undefined ){
//         var ssn = sessionStorage['cemetery_id'];
//         var cid =  obj[0].cemetery_id;
//           html += (parseInt(ssn) == parseInt(cid)) ? "<tr><td style='' align='center'>" + '<a href="/plot-detaiols?id=' + feature.properties.plotid + '&cid=' + cid+'"><button type="button" class="btn btn-secondary">View</button></a>'+"</td></tr>"+
//        "</table>":'';
//       } 
//       return html;
//        });
//        }
//  }

 LoadFile(mappage.id,mymap); 
 
 function LoadFile(id,mymap){
     var post_process = $.post("https://api-dot-ezy-geospatial.appspot.com/user/LoadFile", {
     id:id
   }, function (data) {

    var data = JSON.parse(data);

    $.post("https://api-dot-ezy-geospatial.appspot.com/user/getStatusViaPlotId", {
      cemid:mappage.id
    },function (getStatus) {

    for(var i = 0; i< data.length; i++){
    var url = data[i].url;
   
    $.getJSON(url,function(json){
    var jsondata = json.features;
   //console.log(jsondata);  
 
   var h = JSON.parse(getStatus);
   for(var k=0;jsondata.length > k ; k++){
      var filtered = h.filter(function(item){
      if( item.plot_id == jsondata[k].properties.plotid){
  //      console.log(item.status)
      jsondata[k].properties.status = item.status;    
    }        
});
}
   var shpfile = new L.geoJSON(jsondata,{
       onEachFeature: function(feature, layer) {
        var mappage = getParams(window.location.href);
        geojsondata[feature.properties.plotid] = layer;
  
       layer.bindPopup(function(layer){
        if(layer.feature.properties.plotid) {
       //   console.log(layer.feature.properties);
          var html="<div id='carouselExampleControls' class='carousel slide' data-interval='false' data-ride='carousel'> <div class='carousel-inner'>";
         // console.log(layer.feature.properties.status);
          $.post("https://api-dot-ezy-geospatial.appspot.com/user/AllgetPersonData", {
          status: layer.feature.properties.status,
          plot_id:layer.feature.properties.plotid,
          cemid:mappage.id  
        }, function (plotData ) {
          var obj = JSON.parse(plotData);
          if (typeof obj == 'object') {
          for(var j=0; j<obj.length; j++){
            var count = j + 1; 
            if(j == 0){
            html += "<div class='carousel-item active'> <table class='table' style='white-space:none'> <thead>";
              html += (parseInt(layer.feature.properties.status) !== 2) ? "<th>Record</th><th>" + count + " of " + obj.length + "</th>" : "<th>Status</th><th>Reserved</th>";
             
             html+= "</tr> </thead> <tbody> <tr> <td>ID</td> <td>"+layer.feature.properties.plotid+"</td> </tr> <tr> <td>First Name</td><td>"+obj[j].first_name+"</td> </tr> <tr> <td>Surname</td><td>"+obj[j].surname+"</td> </tr>";
              
            
             html += (parseInt(layer.feature.properties.status) !== 2) ? "<tr><td>Date of Birth</td><td>" + obj[j].dob + "</td> </tr><tr> <td>Date of Death</td> <td>" + obj[j].dod + "</td> </tr><tr> <td>Age</td><td>" + obj[j].age + "</td> </tr></tbody> </table> </div>" : '';
             } else {
              
              html += "<div class='carousel-item'> <table class='table' style='white-space:none'> <thead> <th>Record</th><th>"+count+" of "+obj.length+"</th> </tr> </thead> <tbody> <tr> <td>ID</td> <td>"+layer.feature.properties.plotid+"</td> </tr> <tr> <td>First Name</td><td>"+obj[j].first_name+"</td> </tr> <tr> <td>Surname</td><td>"+obj[j].surname+"</td> </tr>";
              
              html += (parseInt(layer.feature.properties.status) !== 2) ?  "<tr><td>Date of Birth</td><td>"+obj[j].dob+"</td> </tr><tr> <td>Date of Death</td> <td>"+obj[j].dod+"</td> </tr><tr> <td>Age</td><td>"+obj[j].age+"</td> </tr></tbody> </table> </div>":'';
             }
          }

          if(obj.length > 1){
          html+="</div><a class='carousel-control-prev' href='#carouselExampleControls' role='button' data-slide='prev' style=' left: -26px;'> <span class='carousel-control-prev-icon' aria-hidden='true' style='background-color: rgba(0,0,0,0.9);'></span> <span class='sr-only'>Previous</span> </a> <a class='carousel-control-next' href='#carouselExampleControls' role='button' data-slide='next' style=' right: -25px;'> <span class='carousel-control-next-icon' aria-hidden='true' style=' background-color: rgba(0,0,0,0.9);'></span> <span class='sr-only'>Next</span> </a></div>";
        }

          if(obj.length > 0 && sessionStorage['cemetery_id'] !== undefined ){
          
          var ssn = sessionStorage['cemetery_id'];
          var cid =  mappage.id;
          html += (parseInt(ssn) == parseInt(cid)) ? "<tr><td style='' align='center' colspan='2'>" + '<center><a href="/plot-details?id=' + feature.properties.plotid + '&location=' + lati + ',' + longi + '&cid=' + cid + '"><button type="button" class="btn btn-secondary btn-second">View</button></a></center>' + "</td></tr>" +

         "</tbody></div></table>":'';
        } 

        layer.setPopupContent(html);
         
        } else if (obj == false){

          if(sessionStorage['cemetery_id'] !== undefined ){
          var ssn = sessionStorage['cemetery_id'];
          var cid =  mappage.id;

            html += (parseInt(ssn) == parseInt(cid)) ? "<div class='carousel-item active'> <table class='table' style='white-space:none'> <tbody><th>Status</th><th>Vacant</th> <tr> <td>ID</td> <td>" + layer.feature.properties.plotid + "</td> </tr><tr><td style='' align='center' colspan='2'>" + '<center><a href="/plot-details?id=' + feature.properties.plotid + '&location=' + lati +','+longi+'&cid='+cid+'"><button type="button" class="btn btn-secondary">View</button></a></center>'+"</td></tr></tbody> </table> </div></div></div>":'';
        }else{

            html +="<div class='carousel-item active'> <table class='table' style='white-space:none'> <tbody> <th>Status</th><th>Vacant</th> <tr> <td>ID</td> <td>" + layer.feature.properties.plotid + "</td> </tr></tbody> </table> </div></div></div>";
        } 
        layer.setPopupContent(html);

        } else {
       
          if(sessionStorage['cemetery_id'] !== undefined ){
          var ssn = sessionStorage['cemetery_id'];
          var cid =  mappage.id;

            html += (parseInt(ssn) == parseInt(cid)) ? "<div class='carousel-item active'> <table class='table' style='white-space:none'> <tbody><th>Status</th><th>Vacant</th>  <tr>  <td>ID</td> <td>" + layer.feature.properties.plotid + "</td> </tr><tr><td style='' align='center' colspan='2'>" + '<center><a href="/plot-details?id=' + feature.properties.plotid + '&location=' + lati + ',' + longi + '&cid=' + cid +'"><button type="button" class="btn btn-secondary">View</button></a></center>'+"</td></tr></tbody> </table> </div></div></div>":'';
        } 
        layer.setPopupContent(html); 
        }
      });
   }
         return html;
      });  
     },
     
     style: function(feature) {
       if(feature.properties.status == '1'){
         var strokeColor = '#008000';
         var opacity = 0.50;  
       } else if (feature.properties.status == '2'){
         var strokeColor = '#ffe500';
         var opacity = 0.50;
       } else if (feature.properties.status == '3'){
         var strokeColor = '#000fff';
         var opacity = 0.50;
       }else if (feature.properties.status == '4'){
         var strokeColor = '#00ffff';
         var opacity = 0.50;
       }else{
         var strokeColor = '#ffffff';
         var opacity = 0;
       }
       return {
           opacity: opacity,
           fillOpacity:opacity,
           color:strokeColor
       }
     }
   });
   
     shpfile.addTo(mymap);
    });
  } 
 
 
 var legend = L.control({position: 'topright'});
 
   legend.onAdd = function (mymap) {
     var div = L.DomUtil.create('div', 'info legend'),
     
    //  grades = [1, 2, 3, 4],
    //  lable = ["Reserved","Vacant","Occupied","Interested"];
       grades = [1, 2, 3, 4, 5],
       lable = ["Vacant", "Reserved", "Occupied", "Interest","Unavailable"];
     function getColor(d) {

       return d == 1 ? '#008000' :
              d == 2  ? '#ffe500' :
              d == 3  ? '#000fff' :
              d == 4  ? '#00ffff' :
              d == 5 ? '#D63E1E' :
                        '#ffffff';
   }
     // loop through our density intervals and generate a label with a colored square for each interval
     for (var i = 0; i < grades.length; i++) {
       
         div.innerHTML +='<div  style="background:#fff;"><label class="leaflet-panel-layers-title"><i class="leaflet-panel-layers-icon"><i style="background:' + getColor(grades[i]) + ';color: #ffffff;padding: 4px;"></i></i><span class="">'+lable[i]+'</span></label></br></div>';
 
 }
 return div;
 };
 
 legend.addTo(mymap);  
   
     });
    });
          
   }
 
 }

 function test2(plotid){

  
  for(var i in geojsondata){
  if(i == plotid){
    geojsondata[i].openPopup();
    mymap.setView([geojsondata[i]._latlngs[0][0][0].lat, geojsondata[i]._latlngs[0][0][0].lng], 23); 
    }
 }
}

export {test1, test2};
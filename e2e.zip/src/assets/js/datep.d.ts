export declare function datep();

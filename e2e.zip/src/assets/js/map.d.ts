export declare function test1();
export declare function test2(plotid);
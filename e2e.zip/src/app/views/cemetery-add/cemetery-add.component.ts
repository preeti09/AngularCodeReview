import { Observable } from 'rxjs/Rx';
import { Component,OnInit } from '@angular/core';
import { User } from '../../user';
import {Router} from '@angular/router';
import {UserService} from '../../user.service';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import {Location} from "@angular/common";
import {Http} from '@angular/http';

@Component({
  selector: 'app-cemetery-add',
  templateUrl: './cemetery-add.component.html',
  styleUrls: ['./cemetery-add.component.css']
})
export class CemeteryAddComponent implements OnInit {

  userAddForm: FormGroup;
     // user: new User();
      action: string;
      user: any [];
	 constructor( private userService:UserService, private router: Router, private location: Location,
             private formBuilder: FormBuilder, private http:Http) {
   this.buildForm();
 };

  ngOnInit() {
    var userid = sessionStorage.getItem('id');
    if(userid == null){
      this.router.navigate(['/login']);  
    }
     this.userService.getUser().then(res =>{
     this.user = res.json();
      console.log(this.user);
    });

  }

  buildForm(): void {
   this.userAddForm = this.formBuilder.group({
     cemeteryLocation: ['', Validators.required],
     cemeteryName: ['', Validators.required],
     //useid: ['', Validators.required],
     //act:['', Validators.required]
    
     
   });
 }

 addOwner(): void
 {
   let user = this.userAddForm.value;
   console.log(user);
 	this.userService.addOwner(user)
 	.then(res =>{
    
    if(res) 
    {
      this.action= 'Data added successfully';
      window
         setTimeout (() => {this.router.navigate(['/cemeteries'])}, 4000);
    }else
    {
      this.action= 'Some Error please try again';
      window
         setTimeout (() => {this.router.navigate(['/cemeteries'])}, 4000);
    }
 	})
 }

}

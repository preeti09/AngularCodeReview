import { Component, EventEmitter, OnInit, Output, ViewChild, Input, HostBinding } from '@angular/core';
import { FileQueueObject, FileUploaderService } from './file-uploader.service';
import {UserService} from '../../user.service';
import { Observable } from 'rxjs/Observable';
import {FormGroup,FormControl,FormBuilder, Validators} from '@angular/forms';
import {Router} from '@angular/router';
@Component({
  selector: 'file-uploader, [file-uploader]',
  templateUrl: 'file-uploader.component.html',
  styleUrls: ['./file-uploader.component.css']
})

export class FileUploaderComponent implements OnInit {
  
  toolForm: FormGroup;
  user: any [];
  managmenttoolForm: FormGroup;
  imploaddata : any[];
  data : any[];
  afterSelect:boolean = false;
  selectedValue;
  successMessage : object = {};
  IsLoaderShow: boolean;
  
  
  @Output() onCompleteItem = new EventEmitter();
  @ViewChild('fileInput') fileInput;
  queue: Observable<FileQueueObject[]>;

  constructor(public uploader: FileUploaderService ,public router:Router, public userService:UserService) { }

  ngOnInit() {
    this.selectedValue = 'Select Your Area';
    this.managmenttoolForm = new FormGroup({
      cemeteryarea : new FormControl()
      });


      this.userService.CemeteryName().then(res =>{
      this.user = res.json();
      console.log(this.user);
      });

    this.toolForm = new FormGroup({
      cemeteryarea : new FormControl()
   });

    this.queue = this.uploader.queue;
    this.uploader.onCompleteItem = this.completeItem;
  }

  completeItem = (item: FileQueueObject, response: any) => {
    this.onCompleteItem.emit({ item, response });
  }

  addToQueue() {
    const cemid = this.toolForm.value.cemeteryarea;
    var userid = sessionStorage.getItem('id');
    const fileBrowser = this.fileInput.nativeElement;
    this.uploader.addToQueue(fileBrowser.files , cemid ,userid);
  }


  myuploadAll() {
    this.IsLoaderShow = true;
    const cemid = this.toolForm.value.cemeteryarea;
    const fileBrowser = this.fileInput.nativeElement;
    var userid = sessionStorage.getItem('id');
    this.uploader.uploadAll(cemid , userid);
    setTimeout (() => { 
      this.IsLoaderShow = false;
      this.cemeteryDataById();
      this.uploader.clearQueue();
    }, 6000);
   }


  

  cemeteryDataById() {
   const cemid = this.toolForm.value.cemeteryarea;
   console.log(cemid);
   if( cemid !== 'Select Your Area' ){
    this.afterSelect = true;
    
   var userid = sessionStorage.getItem('id');
     this.userService.getDataresultById(userid,cemid).then(res =>{
      this.imploaddata = res.json(); 
    });
   }else{
    this.afterSelect = false;
   }
  }


  userDelete(id) {
    var id = id;
    const cemid = this.toolForm.value.cemeteryarea;
    var userid = sessionStorage.getItem('id');
    this.userService.deleteRecord(id,userid,cemid).then(res =>{
    this.imploaddata = res.json(); 
    console.log(' this.imploaddata', this.imploaddata);
   });
 }

 importData(cemid,filename,url) {
  this.IsLoaderShow = true; 
  this.userService.getimportData(cemid,filename,url).then(res =>{
  if(res.json() == true){
    this.IsLoaderShow = false;
    this.successMessage = { status : true, message : "Data Imported Successfully." };
    setTimeout (() => { 
      this.successMessage = { status : null, message : null };
    }, 3000);
  }else{
    this.IsLoaderShow = false;
    this.successMessage = { status : false, message : "Somthing went wrong!  Please try again." };
    setTimeout (() => { 
      this.successMessage = { status : null, message : null };
    }, 3000);
  }
 });
}
}
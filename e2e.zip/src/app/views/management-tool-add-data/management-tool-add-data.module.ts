import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { ManagementToolAddDataComponent } from './management-tool-add-data.component';
import { FileUploaderComponent } from './file-uploader.component';
import { ManagementToolAddDataRoutingModule } from './management-tool-add-data-routing.module';
import { FileUploaderRoutingModule } from './file-uploader.routing.module';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    ManagementToolAddDataRoutingModule,
    FileUploaderRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule  ],
  declarations: [ ManagementToolAddDataComponent,FileUploaderComponent]
})
export class ManagementToolAddDataModule { }

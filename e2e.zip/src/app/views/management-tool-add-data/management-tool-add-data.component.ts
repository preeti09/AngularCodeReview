import { Component, OnInit } from '@angular/core';
import { User } from '../../user';
import {Router} from '@angular/router';
import {UserService} from '../../user.service';
import {FormGroup,FormControl,FormBuilder, Validators} from '@angular/forms';
import {Location} from "@angular/common";
import {Http} from '@angular/http';

@Component({
  selector: 'app-management-tool-add-data',
  templateUrl: './management-tool-add-data.component.html',
  styleUrls: ['./management-tool-add-data.component.css']
})
export class ManagementToolAddDataComponent implements OnInit {

  managmenttoolForm: FormGroup;
  action:  string;
  user: any [];
  imploaddata : any[];
  
 
   constructor( private userService:UserService, private router: Router, private location: Location,
              private formBuilder: FormBuilder, private http:Http) {
      // this.buildForm();
    
      
    };
 
  
   ngOnInit() {
    var userid = sessionStorage.getItem('id');
    if(userid == null){
      this.router.navigate(['/login']);  
    }

        // this.managmenttoolForm = new FormGroup({
        // cemeteryarea : new FormControl()
        // });


        // this.userService.CemeteryName().then(res =>{
        // this.user = res.json();
        // console.log(this.user);
        // });

        // const cemid = this.toolForm.value.cemeteryarea;
        // console.log('cemid',cemid);
        // var userid = sessionStorage.getItem('id');
        //   this.userService.getDataresultById(userid,cemid).then(res =>{
        //    this.imploaddata = res.json(); 
        //  console.log(' this.imploaddata', this.imploaddata);
        // });
 
   }


  //  cemeteryDataById(id){
  //   console.log('test',id);
  //  }

  //  userDelete(id) {
  //    var id = id;
  //    this.userService.deleteRecord(id).then(res =>{
  //     //this.imploaddata = res.json(); 
  //     this.router.navigate(['/cemetery-management-tool']);
  //   });
  // }

}

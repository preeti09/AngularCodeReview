import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grave-allocation',
  templateUrl: './grave-allocation.component.html',
  styleUrls: ['./grave-allocation.component.css']
})
export class GraveAllocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

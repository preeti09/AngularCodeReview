import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { PlotDetailsRoutingModule } from './plot-details-routing.module';
import { PlotDetailsComponent } from './plot-details.component';

@NgModule({
  imports: [
    CommonModule,
    PlotDetailsRoutingModule,
    FormsModule
  ],
  declarations: [PlotDetailsComponent]
})
export class PlotDetailsModule { }

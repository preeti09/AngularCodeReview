import { Injectable } from '@angular/core';
//import { toPromise } from 'rxjs/operators';
import 'rxjs/add/operator/toPromise';
import {User} from "./user";
import {Headers, Http} from '@angular/http';


@Injectable()

export class UserService{

  GetCemetery(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  updateCemetery(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  
  
  private API_ENDPOINT='https://api-dot-ezy-geospatial.appspot.com/';
  
  //private API_ENDPOINT='http://localhost/cemetery-api/';
 
  
  private host = window.location.hostname;
  private headers = new Headers({'Content-Type': 'application/json'});

  private LoginUrl= this.API_ENDPOINT + `user/amdinLogin`;
  private showUser= this.API_ENDPOINT + `user/showuser`; 
  private OwnerUrl=this.API_ENDPOINT+`user/addOwner`;
  private CemeteryUrl=this.API_ENDPOINT+`user/getCemetery`;
  private GraveData=this.API_ENDPOINT+`user/getGrave`;
  private AddUserUrl=this.API_ENDPOINT+`user/addUser`;
  private GetUpdateUser=this.API_ENDPOINT+`user/updateUser`;
  private UpdateUserData=this.API_ENDPOINT+`user/updateUser`;
  private UserDelete=this.API_ENDPOINT+`user/userDelete`;
  private GetCemeteryUser1=this.API_ENDPOINT+`user/getCemeteryData`;
  private CemeteryUpdate=this.API_ENDPOINT+`user/updateCemeteryData`;
  private DeleteCemetery=this.API_ENDPOINT+`user/cemeteryDelete`;
  private nameCemetery=this.API_ENDPOINT+`user/cemetery`;
  private activeStatus=this.API_ENDPOINT+`user/status`;
  private EmailCheck=this.API_ENDPOINT+`user/emailCheck`;
  private EmailSend=this.API_ENDPOINT+`user/sendEmail`;
  
  private forgotPasswordAPI = this.API_ENDPOINT +`user/ForgotPassword`;
  private Gravedatabyplotid=this.API_ENDPOINT+`user/getGravedataByplotId`;
  private Getpersondatabyid=this.API_ENDPOINT+`user/getPersonDataById`;
  private getFirstByplotId=this.API_ENDPOINT+`user/getFirstByplotId`;
  private getPersonData =this.API_ENDPOINT+`user/getPersonData`;
  private UpdatePersonData =this.API_ENDPOINT+`user/updatePersonData`;
  private editPlotData =this.API_ENDPOINT+`user/updatePlotData`;
  private getresult =this.API_ENDPOINT+`user/getDataresult`;
  private getresultById =this.API_ENDPOINT+`user/getDataresultById`;
  private deleteData =this.API_ENDPOINT+`user/deleteRecordById`;
  private updateRightIntermentData =this.API_ENDPOINT+`user/updateRightIntermentData`;
  private UpdateIntermentData =this.API_ENDPOINT+`user/updateIntermentData`;
  private AddNewBussinessData = this.API_ENDPOINT+`user/insertPersonData`; // ADD NEW PERSON;
  private AddNewPersonData = this.API_ENDPOINT+`user/insert_new_person`; // ADD NEW PERSON;
  private AddNewInterRightIntermentData = this.API_ENDPOINT+`user/insert_inter_right_Data`; // ADD NEW INTERRESTED RIGHT INTERMENT;
  private DoLogin = this.API_ENDPOINT+`user/userLogin`; // USER LOGIN;
  private importData =this.API_ENDPOINT+`user/uploadCSV`;
  private updateGraveImage =this.API_ENDPOINT+`user/uploadGraveImg`;
  private insertNewInterment =this.API_ENDPOINT+`user/insert_add_new_interment`;
  private insertNewRightInterment =this.API_ENDPOINT+`user/insert_new_right_interment`;
  private dashBoardCount =this.API_ENDPOINT+`user/getTableCount`;
  private getDataFuneral =this.API_ENDPOINT+`user/getData_funeralDirector`;
  
  constructor(private http:Http){}
  
  getUser(){
  	return this.http.get(this.LoginUrl)
  	.toPromise()
  	.then(res => {
  		return res;
  	})
  	//.catch(this.handleError);
 }
 
 showuser(){
  return this.http.get(this.showUser)
  .toPromise()
  .then(res => {
    return res;
  })
  //.catch(this.handleError);
}

 getCemetery(){
    return this.http.get(this.CemeteryUrl)
    .toPromise()
    .then(res => {
      return res;
    })
    //.catch(this.handleError);
 }

 dashBoardCountForAdmin(){
  return this.http.post(this.dashBoardCount, {headers: this.headers })
  .toPromise()
  .then(res => {
    return res;
  })
  //.catch(this.handleError);
}

  CemeteryName(){
    return this.http.get(this.nameCemetery)
    .toPromise()
    .then(res => {
      console.log('data',res);
      return res;
    })
    //.catch(this.handleError);
   }
   loginUser(user: User){
     return this.http.post(this.LoginUrl, JSON.stringify(user), {headers: this.headers })
     .toPromise()
     .then(res => res.json() as User)
     //.catch(this.handleError)
 }

 checkEmail(obj){
   return this.http.post(this.EmailCheck, JSON.stringify({ data: obj }), {headers: this.headers })
     .toPromise()
     .then(res => res.json() as User)
     //.catch(this.handleError)
 }
 sendEmail(user){
     return this.http.post(this.EmailSend, JSON.stringify(user), {headers: this.headers })
     .toPromise()
     .then(res => res.json() as User)
     //.catch(this.handleError)
 }

   addOwner(user: User){
     return this.http.post(this.OwnerUrl, JSON.stringify(user), {headers: this.headers })
     .toPromise()
     .then(res => res.json() as User)
     //.catch(this.handleError)
 }

 
  addUser(user: User){
     return this.http.post(this.AddUserUrl, JSON.stringify(user), {headers: this.headers })
     .toPromise()
     .then(res => res.json()
    )
     //.catch(this.handleError)
 }

 getUpdateUser(id){
  const url = `${this.GetUpdateUser}/?id=${id.id}`;
  return this.http.get(url)
    .toPromise()
    .then(res => {
      return res;
    })
    //.catch(this.handleError);
 }

 getCemeteryUser(id){
  const url = `${this.GetUpdateUser}/?id=${id.id}`;
    return this.http.get(url)
    .toPromise()
    .then(res => {
      return res;
    })
    //.catch(this.handleError);
 }


 editPlotDataDetail(data){
  return this.http.post(this.editPlotData, JSON.stringify(data),{headers: this.headers})
  .toPromise()
  .then(res =>res )
} 

 

 getcemetery(id){
  const url = `${this.GetCemeteryUser1}/?id=${id.id}`;
    return this.http.get(url)
    .toPromise()
    .then(res => {
      return res;
    })
    //.catch(this.handleError);
 }

 
 updateUser(user: User){
     return this.http.post(this.UpdateUserData , JSON.stringify(user), {headers: this.headers })
     .toPromise()
     .then(res => res.json() as User)
     //.catch(this.handleError)
 }

 updateDataCemetery(user: User){
     return this.http.post(this.CemeteryUpdate , JSON.stringify(user), {headers: this.headers })
     .toPromise()
     .then(res => res.json() as User)
    // .catch(this.handleError)
 }

 userDelete(id){
     return this.http.post(this.UserDelete, JSON.stringify(id), {headers: this.headers })
     .toPromise()
     .then(res => res.json() as User)
     //.catch(this.handleError)
 }
 
 cemeteryDelete(id){
  return this.http.post(this.DeleteCemetery, JSON.stringify(id), {headers: this.headers })
  .toPromise()
  .then(res => res.json() as User)
//.catch(this.handleError)
}
 
status(data){
  return this.http.post(this.activeStatus, JSON.stringify(data),{headers: this.headers})
  .toPromise()
  .then(res =>res )
} 


// Develped at 28 June 2018

getDataresult(userid){
  return this.http.post(this.getresult, JSON.stringify(userid), {headers: this.headers })
  .toPromise()
  .then(res => {
    return res;
  });
}


getDataresultById(userid,cemid){
  return this.http.post(this.getresultById, JSON.stringify({userid:userid,cemid:cemid}), {headers: this.headers })
  .toPromise()
  .then(res => {
    return res;
  });
}

getPersonData1(person_id,plot_id,cemid){
  return this.http.post(this.getPersonData, JSON.stringify({ person_id: person_id, plot_id: plot_id, cemetery_id: cemid}), {headers: this.headers })
  .toPromise()
  .then(res => {
    return res;
  });
}


deleteRecord(id,userid,cemid){
  return this.http.post(this.deleteData, JSON.stringify({id:id,userid:userid,cemid:cemid}), {headers: this.headers })
  .toPromise()
  .then(res => {
    return res;
  });
  }

  graveData(cemid){
    return this.http.post(this.GraveData, JSON.stringify({cemid:cemid}), {headers: this.headers })
    .toPromise()
    .then(res => {
      return res;
    });
    }
  
  getimportData(cemid,filename,url){
    return this.http.post(this.importData, JSON.stringify({cemid:cemid,filename:filename,url:url}), {headers: this.headers })
    .toPromise()
    .then(res => {
      return res;
    });
  }

  gravedatabyplotid(plot_id){
    return this.http.post(this.Gravedatabyplotid, JSON.stringify({plot_id:plot_id}), {headers: this.headers })
    .toPromise()
    .then(res => {
      return res;
    });
    }

  getFirstDataByplotId(plot_id,cid){
      return this.http.post(this.getFirstByplotId, JSON.stringify({plot_id:plot_id,cemetery_id:cid}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
      }
  
    getpersondatabyid(plot_id){
      return this.http.post(this.Getpersondatabyid, JSON.stringify({plot_id:plot_id}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }
    
    getFuneralData(cemetery_id){
      return this.http.post(this.getDataFuneral, JSON.stringify({cemetery_id:cemetery_id}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }

    updatePersonData(personData,plot_id){
      return this.http.post(this.UpdatePersonData, JSON.stringify({data:personData,plot_id:plot_id}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }

  forgotPasswordAdmin(data) {
    return this.http.post(this.forgotPasswordAPI, JSON.stringify({ data: data}), { headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
  }

    updateRightOfIntermentData(data,plot_id){
      return this.http.post(this.updateRightIntermentData, JSON.stringify({data:data,plot_id:plot_id}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }
    updateIntermentData(data,person_id,plot_id){
      return this.http.post(this.UpdateIntermentData, JSON.stringify({data:data,person_id:person_id,plot_id:plot_id}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }
    addNewPersonData(data){
      return this.http.post(this.AddNewPersonData, JSON.stringify({data:data}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }
    
    AddBusinessData(data){
      return this.http.post(this.AddNewBussinessData, JSON.stringify({data:data}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }

    addNewInterment(data){
      return this.http.post(this.insertNewInterment, JSON.stringify({data:data}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }

    addNewInterRightIntermentData(data){
      return this.http.post(this.AddNewInterRightIntermentData, JSON.stringify({data:data}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }
    doLogin(data){
      return this.http.post(this.DoLogin, JSON.stringify({data:data}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }

    addNewRightInterment(data){
      return this.http.post(this.insertNewRightInterment, JSON.stringify({data:data}), {headers: this.headers })
      .toPromise()
      .then(res => {
        return res;
      });
    }

    postFile(tablename:string,interment_id,plot_id: string,fileToUpload: File) {
      console.log(plot_id,fileToUpload);
      const formData: FormData = new FormData();
      formData.append('file', fileToUpload, fileToUpload.name);
      formData.append('plot_id',plot_id);
      formData.append('table',tablename);
      formData.append('id',interment_id);
      //this.headers.append('Content-Type', 'multipart/form-data');
      return this.http.post(this.updateGraveImage, formData);
    }

} 
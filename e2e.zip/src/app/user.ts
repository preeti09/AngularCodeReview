export class User {
 id:string;
 username: string;
 password: string;
 email: string;
 name: string;
 fname: string;
 lname: string;
 location: string;
 creationdate: string;
 status: string;
 cemeteryid: string;
 first_name: string;
 last_name: string;
 __v?:number;
}
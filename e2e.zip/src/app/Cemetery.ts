export class Cemetery {
    name: string;
    fname: string;
    lname: string;
    location: string;
    creationdate: string;
    status: string;
}
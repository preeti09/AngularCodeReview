import { Component, OnInit } from '@angular/core';
// import {  SimpleLayoutComponent} from "./containers/simple-layout/simple-layout.component";
// import { AppAsideComponent } from '../components/app-aside/app-aside.component';
// import { AppHeaderComponent } from './components/app-header/app-header.component';
// import { AppLeftSideBarComponent } from './components/app-left-side-bar/app-left-side-bar.component';
// import { AppRightSideBarComponent } from './components/app-right-side-bar/app-right-side-bar.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './full-layout.component.html',
  styleUrls: ['./full-layout.component.css']
})

export class FullLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-public-right-side-bar',
  templateUrl: './app-public-right-side-bar.component.html',
  styleUrls: ['./app-public-right-side-bar.component.css']
})
export class AppPublicRightSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

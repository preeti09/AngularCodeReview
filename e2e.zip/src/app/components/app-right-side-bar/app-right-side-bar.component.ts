import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-side-bar',
  templateUrl: './app-right-side-bar.component.html',
  styleUrls: ['./app-right-side-bar.component.css']
})
export class AppRightSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

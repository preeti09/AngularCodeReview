import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-public-aside',
  templateUrl: './app-public-aside.component.html',
  styleUrls: ['./app-public-aside.component.css']
})
export class AppPublicAsideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
